


**********************************************************
*************  Important Instructions Follow  ************
**********************************************************

All files exported to: Z:\\18\\28\\1828410\\103\Eagle\2014-07-22_02-09-03\2014-07-22_02-09-03.xml


To import your new library into Eagle:
1. Start Eagle.
2. Select File -> New -> Library from the menu.
3. In the blank library window, select File -> Execute Script from the menu.
5. Browse to your newly exported Eagle Script file (".scr" file extension)
6. After opening the file, the script will populate the new library.
7. Use File -> Save (or Save As..) to save the library to the desired location in Eagle native format.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Eagle_import.html

You may also find this video helpful:
http://youtu.be/5jGuWY-Yy3Q


Component "06035A220FAT2A" renamed to "06035A220FAT2A"


Ultra Librarian Gold 6.4.30 Process Report


Message - Padstack "RX26Y38D0T" Shape(4) is a CIRCLE with no diameter.
Message - Component "06035A220FAT2A" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "06035A220FAT2A" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "06035A220FAT2A" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "06035A220FAT2A" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "06035A220FAT2A" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.

TextStyle count:  25
Padstack count:   2
Pattern count:    1
Symbol count:     1
Component count:  1

Export

