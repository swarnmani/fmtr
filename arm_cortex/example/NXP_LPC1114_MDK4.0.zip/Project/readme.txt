Chip��
    LPC1114F301

Evaluation Board��
    LPC1100

Development Environment��
    Keil RealView MDK 4.00

Complier��
    ARMCC

Tasks:    
    taskBlink0: LED0 (PORT2.1) blink with speed of 0.2s
    taskBlink1: LED1 (PORT2.2) blink with speed of 0.4s

Descriptions:
    The project is a simple program of LED Blink for the LPC1100 based on Coocox OS.

System Configuration:
    XTAL   freq      =  12.00 MHz
    SYSCLK freq      =  48.00 MHz
    System Tick freq = 100Hz (10ms)