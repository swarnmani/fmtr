
App:     Application source code
CMSIS:   ARM CMSIS V1.0
CoOS:    Coocox CoOS source code
lib:     Library source code 
Project: Makefile project